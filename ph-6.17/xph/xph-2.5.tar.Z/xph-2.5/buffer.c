/* buffer.c -- global buffer data for client-server processing.
 *
 * Last edited: Fri Sep 24 18:22:43 1993 by bcs (Bradley C. Spatz) on altitude
 *
 * Copyright (C) 1993, Bradley C. Spatz, bcs@ufl.edu
 */

#include "copyright.h"


/* According to my database at my site, some fields maintained by the
 * server can be up to 4K in size.  Accordingly, I have to maintain
 * a large buffer for this purpose.  I keep some other miscellaneous
 * buffers as well.  I know this really sucks.
 */
#define FOUR_K 4096

char buf[FOUR_K + 128];
char line[128];
char response[128];
char reply[128];
