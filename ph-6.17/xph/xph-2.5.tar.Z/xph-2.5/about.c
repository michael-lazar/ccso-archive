/* about.c -- goop to do the fancy "About xph" dealie.
 *
 * Last edited: Mon Oct  4 18:57:03 1993 by bcs (Bradley C. Spatz) on altitude
 *
 * Copyright (C) 1993, Bradley C. Spatz, bcs@ufl.edu
 */

#include "copyright.h"

#include <stdio.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <X11/StringDefs.h>
#include <X11/Xaw/AsciiText.h>
#include <X11/Xaw/Cardinals.h>
#include <X11/Xaw/Command.h>
#include <X11/Xaw/Form.h>

#include "bcs.xbm"
#include "global.h"

/* Declare some variables global to this module, for convenience, and
 * to make debugging interesting.  ;-)
 */
static Widget about_popup=NULL;
static void dismiss_about();
static Pixmap pixmap;

static char brag[] =
"Xph 2.5 \n\
\n\
Bradley C. Spatz\n\
Computer & Information Sciences\n\
University of Florida\n\
bcs@ufl.edu\n\
\n\
\"My first X program.  Bad, huh?\"\
";


static char contribs[] =
"With lots-o-help from:\n\
\n\
\"Joaquim Baptista\" <px@fct.unl.pt>\n\
   (help directory parsing)\n\
\"Mark D. Baushke\" <mdb@NSD.3Com.COM>\n\
\"Sullivan Beck\" <beck@qtp.ufl.edu>\n\
\"John Cavanaugh\" <cavanaug@lees.cogsci.uiuc.edu>\n\
\"Robert Forsman\" <thoth@cis.ufl.edu>\n\
   (gratuitous bitmap magic)\n\
\"Ted Frohling\" <tsf@opus.telcom.arizona.ed>\n\
\"Rick Lewis\" <LewisRW@nersc.gov>\n\
   (scrolling server list)\n\
\"John C.H. Lin\" <lin@cs.purdue.edu>\n\
   (editing multi-line fields)\n\
\"Malcolm C. Strickland\" <chucks@orl.mmc.com>\n\
\n\
Thanks folks!\
";


#define TEXT_WIDTH 300


void about_xph(widget, client_data, call_data)
Widget	widget;		
XtPointer client_data, call_data;
{
    Widget	aform, acore, atext, atext2, adismiss;
    Position	x, y;
    Dimension	width, height;
    Display     *disp;
    int         scr;
    Visual      *vis;

    /* We think we're coming from a real widget, but actually from a
     * transient menu popup that's going away...snag a reference to its
     * static grandparent.
     */
    widget = XtParent(XtParent(widget));
    
    /* Only create this testament to vanity once. */
    if (about_popup == NULL) {
       about_popup = XtVaCreatePopupShell("about_xph",
					  transientShellWidgetClass, widget,
					  XtNtitle, "About Xph",
					  XtNiconPixmap, icon_pixmap, NULL);

       aform = XtCreateManagedWidget("aform", formWidgetClass, about_popup,
				     NULL, ZERO);

       /* Now create a pixmap and make it the background of the core. */
       disp = XtDisplay(about_popup);
       scr = DefaultScreen(disp);
       pixmap = XCreatePixmapFromBitmapData(disp, DefaultRootWindow(disp),
					    bcs_bits, bcs_width, bcs_height,
					    BlackPixel(disp, scr),
					    WhitePixel(disp, scr),
					    DefaultDepth(disp, scr));

       acore = XtVaCreateManagedWidget("acore", coreWidgetClass, aform,
				       XtNbackgroundPixmap, pixmap,
				       XtNwidth, bcs_width,
				       XtNheight, bcs_height,
				       NULL);
       
       atext = XtVaCreateManagedWidget("atext", asciiTextWidgetClass, aform,
					XtNdisplayCaret, FALSE,
					XtNwidth, TEXT_WIDTH,
					XtNheight, bcs_height,
					XtNstring, brag, NULL);

       atext2 = XtVaCreateManagedWidget("atext2", asciiTextWidgetClass, aform,
					XtNdisplayCaret, FALSE,
					XtNwidth, (TEXT_WIDTH+bcs_width+6),
					XtNstring, contribs,
					NULL);
       
       adismiss = XtCreateManagedWidget("adismiss", commandWidgetClass, aform,
					NULL, ZERO);
       XtAddCallback(adismiss, XtNcallback, pop_down_widget,
		     (XtPointer) aform);
    }

#if 1
    /* Position the widget so that we end up in the output window,
     * where we like it.  ;-)
     */
    XtVaGetValues(widget, XtNwidth, &width, XtNheight, &height, NULL);
    XtTranslateCoords(widget, (Position) (width / 2),
		      (Position) (height / 2), &x, &y);
    XtVaSetValues(about_popup, XtNx, x-TEXT_WIDTH-bcs_width, XtNy, y-50, NULL);
#endif
    
    XtPopup(about_popup, XtGrabExclusive);

#if 0
    /* Finally, find out the width and height of the window and set the
     * max values to this, thus disallowing any resizing.  My face is
     * already perfectly proportioned...
     */
    XtVaGetValues(about_popup, XtNwidth, &width, XtNheight, &height,
		  NULL);
    XtVaSetValues(about_popup, XtNmaxWidth, width, XtNminWidth, width,
		  XtNmaxHeight, height, XtNminHeight, height, NULL);
#endif
}


static void
dismiss_about(widget, client_data, call_data)
Widget	widget;		
XtPointer client_data, call_data;
{
#if 0
   Display *disp;
   int scr;
   Widget parent;

   disp = XtDisplay((Widget) client_data);
   scr = DefaultScreen(disp);
   XFreePixmap(disp, pixmap);
   XtDestroyWidget(XtParent((Widget) client_data));
#else
   XtPopdown(about_popup);
#endif
}
