/* servers.c -- routines to secure and grok the Ph server list.
 *
 * Scrolling server list by Rick Lewis, lewisrw@nersc.gov
 *
 * Last edited: Mon Oct  4 10:48:49 1993 by bcs (Bradley C. Spatz) on altitude
 *
 * Copyright (C) 1993, Bradley C. Spatz, bcs@ufl.edu
 */

#include "copyright.h"

#include <stdio.h>
#include <string.h>
#include <X11/cursorfont.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <X11/StringDefs.h>
#include <X11/Xaw/Form.h>
#include <X11/Xaw/Cardinals.h>
#include <X11/Xaw/MenuButton.h>
#include <X11/Xaw/SimpleMenu.h>
#include <X11/Xaw/Sme.h>
#include <X11/Xaw/SmeBSB.h>
#include <X11/Xaw/SmeLine.h>

#include <X11/Xaw/AsciiText.h>
#include <X11/Xaw/Text.h>
#include <X11/Xaw/TextSrc.h>
#include <X11/Xaw/TextSink.h>
#include <X11/Xaw/AsciiSrc.h>
#include <X11/Xaw/AsciiSink.h>

#include "resource.h"
extern xph_res_t xphres;
#include "global.h"
#include "replies.h"

extern Widget label, pshell;

/* Describe a structure to record the server list. */
#define MAX_SERVERS             500
#define MAX_SITENAME_SIZE	60
typedef struct {
   char *site;
   char *server;
   char *domain;
} server_list_t;
server_list_t server_list[MAX_SERVERS];
int num_servers = 0;
int list_size = 0;
char *list_string;

#define QUERY "query name=ns-servers type=serverlist return text\n"

void test_action() 
{
   printf("Hey Rick, it recognized the single click properly.\n");
}

/* Pop up the form widget containing the scrolling text widget.
   Position it slightly lower and to the right from the origin
   of the parent "xph" window.
*/
void hey_there(w, client_data, call_data)
Widget w;
XtPointer client_data;
XtPointer call_data;
{
   Widget pshell = (Widget) client_data;
   Position fx, fy, x, y;
   Arg arg[2];
   
   XtVaGetValues(XtParent(pshell), /* Where's daddy? */
	XtNwidth, &fx,
	XtNheight, &fy,
	NULL);

   XtTranslateCoords(XtParent(pshell), 
	(Position) 20,
	(Position) 20,
	&x, &y);


   XtVaSetValues(pshell,	/* Position the menu form widget */
	XtNx, (Position) x,
	XtNy, (Position) y,
        XtNtitle, "Select a New Ph Site",
	NULL);

/* Bradley does this to Rick's code for personal aesthetics. */
#if 0
   XtPopup(pshell, XtGrabNonexclusive);	/* Launch it */
#else
   XtPopup(pshell, XtGrabExclusive);	/* Launch it */
#endif

}

int get_server_list()
{
   int code=0, has_domain=0;
   char *text, *token, *value;

   /* Send off the query.  The response will either be success or failure.
    * If failure, then eat the data.  Otherwise eat only the success line.
    */
   write_ns(QUERY);
   read_ns(buf);
   if (atoi(buf) < 0) {
      do {
	 read_ns(buf);
      } while (atoi(buf) < 0);
      return(1);
   }
   else {
      read_ns(buf);
      while (atoi(buf) != LR_OK) {
	 /* Parse the individual line and determine the token.  Then
	  * allocate storage for and record the value.  Make sure to
	  * increment the number of servers in our list.  Make a paranoid
	  * check when we increment to make sure our static array is
	  * big enough.
	  */
	 text = (char *) (word(buf, ':', 3) + 1);
	 token = strtok(text, ":");
	 value = strtok(NULL, ":");
	 if (strcmp(token, "site") == 0) {
	    num_servers++;
	    if (num_servers > MAX_SERVERS) {
	       fprintf(stderr, "get_server_list: server list not big enough!\n");
	       num_servers--;
	    }
	    server_list[num_servers - 1].domain = NULL;

            list_size+=(strlen(value) +1);
	    server_list[num_servers - 1].site = (char *) malloc ((strlen(value) + 1) * sizeof(char));
	    strcpy(server_list[num_servers - 1].site, value);
	 }
	 else if (strcmp(token, "server") == 0) {
	    server_list[num_servers - 1].server = (char *) malloc ((strlen(value) + 1) * sizeof(char));
	    strcpy(server_list[num_servers - 1].server, value);
	 }
	 else if (strcmp(token, "domain") == 0) {
	    server_list[num_servers - 1].domain = (char *) malloc ((strlen(value) + 1) * sizeof(char));
	    strcpy(server_list[num_servers - 1].domain, value);
	    has_domain = 1;
	 }
	 else {
	    /* Whoops.  An error. */
	    fprintf(stderr, "get_server_list: unknown token: '%s'\n", token);
	 }

	 read_ns(buf);
      }
   }

#ifdef DEBUG
{
   int i;

   fprintf(stderr, "Got %d entries:\n", num_servers);
   for (i=0; i< num_servers; i++) {
      fprintf(stderr, "Site:   %s\n", server_list[i].site);
      fprintf(stderr, "Server: %s\n", server_list[i].server);
      fprintf(stderr, "Domain: %s\n\n", (server_list[i].domain == NULL) ? "(none)" : server_list[i].domain);
   }
}
#endif

return(0);
}


extern Widget help;

static void
change_server(i)
int i;
{
   busy_cursor();

   /* Connect to a new server.  Make sure to reset all the state
    * we've established.  Test for now.
    */
   close_connection();
   connect_to_server(server_list[i].server, xphres.service);
   XtVaSetValues(label,XtNlabel,server_list[i].site,NULL);
   sprintf(buf, "Connected to new server (%s).\n\n", server_list[i].site);
   XawAsciiSaveTextPosition(text);
   XawAsciiAppend(text, buf);
   XawAsciiRestoreTextPosition(text);
   create_help_menu(help);
   check_status();
   unbusy_cursor();
}


/* This routine creates the list of servers known to our default server.
 * It maps the the menu items to a routine do manage such a selection.
 */
void create_server_menu(widget)
Widget widget;		
{
   Widget slmenu, slitem;
   String site_name;
   int i;
   
   /* Create a simple popup menu that lists the server site names known to
    * our current default server.
    */
   XtVaSetValues(widget, XtNmenuName, "slmenu", NULL);

   /* Make sure our server has a list. */
   if (get_server_list()) {
      /* No help is available. */
      slmenu = XtVaCreatePopupShell("slmenu", simpleMenuWidgetClass, widget,
				    XtNlabel, "No site list is available.",
				    NULL);
   }
   else {
      XtVaSetValues(widget, XtNlabel, server_list[0].site, NULL);
      slmenu = XtVaCreatePopupShell("slmenu", simpleMenuWidgetClass, widget,
				    XtNlabel, "Select a Ph server:", NULL);
      slitem = XtCreateManagedWidget("slline", smeLineObjectClass, slmenu,
				     NULL, ZERO);
      for (i=0; i<num_servers; i++) {
	 site_name = server_list[i].site;
	 slitem = XtCreateManagedWidget(site_name, smeBSBObjectClass, slmenu,
					NULL, ZERO);
	 XtAddCallback(slitem, XtNcallback, change_server, (XtPointer) i);
      }
   }
}


/* Popdown the server menu, for the user has hit "Cancel"
*/
void cancel_server_text_list(w, client_data, call_data)
Widget w;
XtPointer client_data;
XtPointer call_data;
{
   Widget pshell = (Widget) client_data;

   XtPopdown(pshell);
}

/* Match the selection (in the cut buffer) with one of the
   sites in the list.  Call change_server to connect to it.
*/
void check_and_change(w, client_data, call_data)
Widget w;
XtPointer client_data;
XtPointer call_data;
{
   Widget textWidget = (Widget) client_data;
   int i=0,x;
   char selected_site[MAX_SITENAME_SIZE];
   char found=FALSE;

   /* Put the selection in "selected_site" string */
   strcpy(selected_site, strtok(XFetchBytes(XtDisplay(textWidget), &x),"\n"));

   /* Look for a match */
   /* P.S. This is highly paranoid */
   while ( !found && (i<num_servers)) {
      found = !strcmp(server_list[i].site,selected_site);
      ++i;
   }
   /* If it's a valid server, change to it */
   XtPopdown(pshell);
   if (found) {
      --i;
      change_server(i);
   }
}
       

/* Create a form widget containing a text widget and two command
   widgets.  The text widget scrolls the server list, and is
   tweaked with "XawTextSetSelectionArray" to highlight a full
   site name with a single click (no triple click neccessary)
*/
void create_server_text_list(widget)
Widget widget;		
{
   Widget boxForm, boxLabel, textList, cancelButton, connectButton;
   String site_name;
   XawTextSelectType *sel_type_array;
   int i;
   
   sel_type_array = (XawTextSelectType *)malloc(3*sizeof(XawTextSelectType));
   sel_type_array[0] = XawselectLine;	/* Single click highlights line */
   sel_type_array[1] = XawselectLine;	/* Single click highlights line */
   sel_type_array[2] = XawselectNull;   /* Subsequent clicks ignored */

   /* Make sure our server has a list. */
   if (!get_server_list()) {
      boxForm = XtVaCreateManagedWidget("boxForm", formWidgetClass,
					 widget, NULL);
#if 1
      boxLabel = XtVaCreateManagedWidget("boxLabel", labelWidgetClass,
					 boxForm, NULL);
#endif
      textList = XtVaCreateManagedWidget("textList",asciiTextWidgetClass,
					 boxForm, 
					 XtNscrollVertical, 
					 XawtextScrollWhenNeeded, 
					 XtNscrollHorizontal,
					 XawtextScrollWhenNeeded,
					 NULL); 

      XawTextSetSelectionArray(textList, sel_type_array); 

      connectButton = XtVaCreateManagedWidget("connectButton",
					      commandWidgetClass, boxForm,
					 XtNlabel, "Connect to Selected Site",
					 NULL);

      cancelButton = XtVaCreateManagedWidget("cancelButton",commandWidgetClass,
					     boxForm, XtNlabel, "Close",
					     NULL);

      /* Create the "text" for the textList widget.  It consists of a single
	 string, containing each site, sites delimited by \n */
      list_string = (String) malloc(list_size * sizeof(char));
      *list_string = '\0';
      for (i=0; i<num_servers; i++) {
         strcat(list_string, server_list[i].site);
         if (i != (num_servers-1)) {
	    strcat(list_string,"\n");
         }
      }

      XtVaSetValues(textList, XtNstring, list_string, NULL);

      XtAddCallback(cancelButton, XtNcallback, cancel_server_text_list, widget);
      
      XtAddCallback(connectButton, XtNcallback, check_and_change, textList);
   }
}

