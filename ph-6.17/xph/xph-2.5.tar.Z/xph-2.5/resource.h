/* resource.h -- describe structures to hold our own resources.
 *
 * Copyright (C), 1992, Bradley C. Spatz, bcs@ufl.edu.
 * Last edited: Wed Apr 22 11:05:49 1992 by bcs (Bradley C. Spatz) on frenulum
 */

/* Create some resources for the server and service of the nameserver. */
typedef struct Xph_Resources {
   String alias;     /* Our default alias. */
   String server;    /* What host provides the service? */
   String service;   /* What service (port name) do we use? */
} xph_res_t;

#define offset(field) XtOffset(struct Xph_Resources*, field)
