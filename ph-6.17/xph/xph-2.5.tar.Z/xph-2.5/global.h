/* global.h -- global declarations and exported prototypes.
 *
 * Copyright (C) 1992, Bradley C. Spatz, bcs@ufl.edu
 * Last edited: Wed Apr 22 11:04:49 1992 by bcs (Bradley C. Spatz) on frenulum
 */

/* about.c: */
void about_xph();

/* buffer.c: */
extern char buf[];
extern char line[];
extern char response[];
extern char reply[];

/* busy.c: */
void init_busy_cursor();
void busy_cursor();
void unbusy_cursor();

/* change.c: */
extern Widget change_popup;

/* fullpage.c: */
extern void do_fullpage();

/* help.c: */
extern void create_help_menu(); 

/* login.c: */
extern int logged_in;
extern char login_password[];

/* misc.c: */
extern void pop_down_widget();
extern void destroy_widget();

/* password.c: */
extern void change_password();

/* query.c */
extern char *word();

/* xph.c: */
extern Pixmap icon_pixmap;
extern Widget toplevel;
extern Widget text;
extern char login_alias[];
extern int read_only;
